import pandas as pd
import random

topics = [
    "weather", "sports", "finance", "technology", "health",
    "music", "education", "travel", "food", "movies"
]

doc_templates = [
    "This document discusses {} in detail.",
    "An overview of the latest trends in {}.",
    "The impact of {} on daily life.",
    "Recent developments in {}.",
    "Understanding the basics of {}."
]

query_doc_pairs = []
for i in range(10):
    topic = random.choice(topics)
    query = f"What is new in {topic}?"
    doc = random.choice(doc_templates).format(topic)
    query_doc_pairs.append([query, doc])

df = pd.DataFrame(query_doc_pairs, columns=["query", "document"])
print(df)





from elasticsearch import Elasticsearch, helpers
import time

# 1. Connect to ES (edit the host/port as needed)
es = Elasticsearch("http://localhost:9200")
index_name = "bm25-demo"

# 2. Delete index if it exists (for repeatable demo)
if es.indices.exists(index=index_name):
    es.indices.delete(index=index_name)

# 3. Create index with BM25 (standard analyzer by default)
mapping = {

    "mappings": {
        "properties": {
            "content": {
                "type": "text",  # Uses BM25 and standard analyzer by default
            }
        }
    }
}
es.indices.create(index=index_name, body=mapping)
print(f"Created index '{index_name}'.")

# 4. Index a few documents
docs = [
    {"content": "The stock market saw gains today in the finance sector."},
    {"content": "Technology advances are happening at a rapid pace."},
    {"content": "Healthy eating and exercise improve overall health."},
    {"content": "Weather forecasts predict rain this week."},
    {"content": "Financial experts recommend saving early for retirement."},
]
actions = [{"_index": index_name, "_source": doc} for doc in docs]
helpers.bulk(es, actions)
print("Indexed documents.")
time.sleep(1)  # Let ES index the docs



import sys
sys.path.append('/Users/keqiaoli/Desktop/RankingSHAP/RankingShap/')
# import rankingSHAP_test_class_cutomized
from rankingSHAP_test_class_cutomized import extract_es_features_optimized 
# from rankingSHAP_test_class import extract_es_features_optimized
# ----- Usage -----
es = Elasticsearch("http://localhost:9200")
index_name = "bm25-demo"

# Extract features using the optimized method
features = extract_es_features_optimized(es, index_name, field="content")
print(features)







from elasticsearch import Elasticsearch, helpers
import sys
import os
from pathlib import Path

def extract_features_from_documents(documents, index_name="bm25-demo", es_host="http://localhost:9200", field="content"):
    """
    Extract features from documents using Elasticsearch and RankingSHAP.
    
    Args:
        documents (list): List of dictionaries with document content
                         Format: [{"content": "text1"}, {"content": "text2"}, ...]
        index_name (str): Name of the Elasticsearch index to create
        es_host (str): Elasticsearch host URL
        field (str): Field name to analyze for features
    
    Returns:
        features: Extracted features from RankingSHAP, or None if error occurs
    """
    
    # 1. Connect to ES with error handling
    try:
        es = Elasticsearch(es_host)
        if not es.ping():
            raise ConnectionError("Cannot connect to Elasticsearch")
        print("Successfully connected to Elasticsearch")
    except Exception as e:
        print(f"ES connection failed: {e}")
        return None
    
    # 2. Delete index if it exists (for repeatable execution)
    try:
        if es.indices.exists(index=index_name):
            es.indices.delete(index=index_name)
            print(f"Deleted existing index '{index_name}'")
    except Exception as e:
        print(f"Error deleting index: {e}")
        return None
    
    # 3. Create index with BM25 (standard analyzer by default)
    mapping = {
        "mappings": {
            "properties": {
                field: {
                    "type": "text",  # Uses BM25 and standard analyzer by default
                }
            }
        }
    }
    
    try:
        es.indices.create(index=index_name, **mapping)
        print(f"Created index '{index_name}'.")
    except Exception as e:
        print(f"Error creating index: {e}")
        return None
    
    # 4. Index the provided documents
    if not documents:
        print("No documents provided")
        return None
    
    actions = [{"_index": index_name, "_source": doc} for doc in documents]
    
    try:
        response = helpers.bulk(es, actions)
        print(f"Successfully indexed {len(documents)} documents")
    except helpers.BulkIndexError as e:
        print(f"Bulk indexing errors: {e.errors}")
        return None
    except Exception as e:
        print(f"Unexpected error during bulk indexing: {e}")
        return None
    
    # Refresh index to make documents searchable immediately
    try:
        es.indices.refresh(index=index_name)
        print("Index refreshed")
    except Exception as e:
        print(f"Error refreshing index: {e}")
    
    # 5. Import custom module and extract features
    try:
        # Get the current script's directory
        current_dir = Path.cwd()
        rankingshap_path = current_dir / "RankingSHAP" / "RankingShap"
        
        # Add to path if it exists
        if rankingshap_path.exists():
            sys.path.insert(0, str(rankingshap_path))
        else:
            # Fallback to your original path (make it configurable)
            fallback_path = "/Users/keqiaoli/Desktop/RankingSHAP/RankingShap/"
            if os.path.exists(fallback_path):
                sys.path.append(fallback_path)
            else:
                raise ImportError(f"RankingSHAP module not found at expected locations")
        
        from rankingSHAP_test_class_cutomized import extract_es_features_optimized
        
        # Extract features using the optimized method
        features = extract_es_features_optimized(es, index_name, field=field)
        print("Extracted features:")
        print(features)
        return features
        
    except ImportError as e:
        print(f"Import error: {e}")
        print("Please check the path to your RankingSHAP module")
        return None
    except Exception as e:
        print(f"Error extracting features: {e}")
        return None


"""Example of how to use the extract_features_from_documents function"""

# Sample documents
docs = [
    {"content": "The stock market saw gains today in the finance sector."},
    {"content": "Technology advances are happening at a rapid pace."},
    {"content": "Healthy eating and exercise improve overall health."},
    {"content": "Weather forecasts predict rain this week."},
    {"content": "Financial experts recommend saving early for retirement."},
]

# Extract features
features = extract_features_from_documents(documents=docs)

if features is not None:
    print("Feature extraction completed successfully!")

else:
    print("Feature extraction failed!")




from elasticsearch import Elasticsearch, helpers
from typing import List, Dict, Any, Optional
import uuid

class ElasticsearchSparseSearchModel:
    """
    A simple Elasticsearch sparse search model with scikit-learn-like interface.
    Uses BM25 scoring for sparse retrieval.
    """
    
    def __init__(self, es_host: str = "http://localhost:9200", index_name: Optional[str] = None):
        """
        Initialize the Elasticsearch sparse search model.
        
        Args:
            es_host (str): Elasticsearch host URL
            index_name (str, optional): Index name. If None, generates a random one.
        """
        self.es_host = es_host
        self.index_name = index_name or f"sparse_search_{uuid.uuid4().hex[:8]}"
        self.es = None
        self.is_fitted = False
        self.field_name = "content"
        
    def _connect(self):
        """Establish connection to Elasticsearch."""
        if self.es is None:
            try:
                self.es = Elasticsearch(self.es_host)
                if not self.es.ping():
                    raise ConnectionError("Cannot connect to Elasticsearch")
                print(f"Connected to Elasticsearch at {self.es_host}")
            except Exception as e:
                raise ConnectionError(f"Failed to connect to Elasticsearch: {e}")
    
    def fit(self, documents: List[str]) -> 'ElasticsearchSparseSearchModel':
        """
        Fit the model by indexing documents into Elasticsearch.
        
        Args:
            documents (List[str]): List of document texts to index
            
        Returns:
            self: Returns the instance for method chaining
        """
        self._connect()
        
        # Delete existing index if it exists
        if self.es.indices.exists(index=self.index_name):
            self.es.indices.delete(index=self.index_name)
            print(f"Deleted existing index '{self.index_name}'")
        
        # Create index with BM25 settings
        mapping = {
            "mappings": {
                "properties": {
                    self.field_name: {
                        "type": "text",
                        "analyzer": "standard"  # Uses BM25 by default
                    }
                }
            }
        }
        
        try:
            self.es.indices.create(index=self.index_name, **mapping)
            print(f"Created index '{self.index_name}'")
        except Exception as e:
            raise RuntimeError(f"Failed to create index: {e}")
        
        # Index documents
        actions = []
        for i, doc in enumerate(documents):
            actions.append({
                "_index": self.index_name,
                "_id": i,
                "_source": {self.field_name: doc}
            })
        
        try:
            helpers.bulk(self.es, actions)
            self.es.indices.refresh(index=self.index_name)
            print(f"Indexed {len(documents)} documents")
            self.is_fitted = True
        except Exception as e:
            raise RuntimeError(f"Failed to index documents: {e}")
        
        return self
    
    def predict(self, queries: List[str], top_k: int = 5) -> List[List[Dict[str, Any]]]:
        """
        Perform sparse search predictions for given queries.
        
        Args:
            queries (List[str]): List of query strings
            top_k (int): Number of top results to return per query
            
        Returns:
            List[List[Dict]]: For each query, returns list of top_k results.
                            Each result contains: {'doc_id', 'score', 'content'}
        """
        if not self.is_fitted:
            raise RuntimeError("Model must be fitted before making predictions. Call .fit() first.")
        
        results = []
        
        for query in queries:
            # Elasticsearch query using BM25
            search_body = {
                "query": {
                    "match": {
                        self.field_name: query
                    }
                },
                "size": top_k,
                "_source": [self.field_name]
            }
            
            try:
                response = self.es.search(index=self.index_name, body=search_body)
                
                query_results = []
                for hit in response['hits']['hits']:
                    result = {
                        'doc_id': hit['_id'],
                        'score': hit['_score'],
                        'content': hit['_source'][self.field_name]
                    }
                    query_results.append(result)
                
                results.append(query_results)
                
            except Exception as e:
                print(f"Error searching for query '{query}': {e}")
                results.append([])  # Return empty results on error
        
        return results
    
    def predict_single(self, query: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """
        Convenience method for single query prediction.
        
        Args:
            query (str): Single query string
            top_k (int): Number of top results to return
            
        Returns:
            List[Dict]: List of top_k results for the query
        """
        results = self.predict([query], top_k)
        return results[0] if results else []
    
    def cleanup(self):
        """Delete the index and clean up resources."""
        if self.es and self.es.indices.exists(index=self.index_name):
            self.es.indices.delete(index=self.index_name)
            print(f"Deleted index '{self.index_name}'")



# Sample documents
documents = [
    "The stock market saw gains today in the finance sector.",
    "Technology advances are happening at a rapid pace.",
    "Healthy eating and exercise improve overall health.",
    "Weather forecasts predict rain this week.",
    "Financial experts recommend saving early for retirement.",
    "Machine learning models require large datasets for training.",
    "The weather today is sunny and warm.",
    "Exercise and diet are key to maintaining good health."
]

# Create and fit the model
model = ElasticsearchSparseSearchModel()
# Fit the model
print("Fitting model with documents...")
model.fit(documents)


from utils.get_explanations import calculate_all_query_explanations
from utils.helper_functions import get_data
import numpy as np
from scipy.stats import kendalltau

from approaches.ranking_shap import RankingShap

from pathlib import Path




explanation_size = 5


num_features = len(features)
# background_data = BackgroundData(
#     np.full((1, num_features), '<unk>'),  # Replace with the desired number of rows and features
#     summarization_type=None,
# )

background_data_new = np.full((1, num_features), '<unk>', dtype=object)





import approaches.ranking_shap as ranking_shap_module
import importlib
importlib.reload(ranking_shap_module)

from approaches.ranking_shap import RankingShap
import rbo




rank_similarity_coefficient = lambda x, y: rbo(x, y, p=0.9)

# Define all the explainers
ranking_shap_explainer = RankingShap(
    permutation_sampler="kernel",
    background_data=background_data_new,
    original_model=model.predict,
    explanation_size=20,
    name="rankingshap",
    rank_similarity_coefficient=rank_similarity_coefficient,
)

features_selection, feature_attribution = ranking_shap_explainer.get_query_explanation(
    query_features=features, query_id="12345"
)
