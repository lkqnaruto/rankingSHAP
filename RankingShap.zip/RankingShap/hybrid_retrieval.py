import pandas as pd
import numpy as np
import faiss
import time
import re
from sentence_transformers import SentenceTransformer, CrossEncoder
from rank_bm25 import BM25Okapi

class DenseRetriever:
    def __init__(self, model_name='all-mpnet-base-v2'):
        """
        Initialize the Dense Retriever using sentence transformers
        
        Args:
            model_name (str): Name of the sentence transformer model to use
        """
        # Load the SentenceTransformer model
        self.model = SentenceTransformer(model_name)
        self.index = None
        self.documents = None
        self.doc_ids = None
        
    def encode_documents(self, documents, batch_size=32):
        """
        Encode documents into embeddings
        
        Args:
            documents (list): List of document texts
            batch_size (int): Batch size for encoding
            
        Returns:
            np.ndarray: Document embeddings
        """
        print(f"Encoding {len(documents)} documents...")
        start_time = time.time()
        embeddings = self.model.encode(documents, batch_size=batch_size, show_progress_bar=True)
        elapsed_time = time.time() - start_time
        print(f"Encoding completed in {elapsed_time:.2f} seconds")
        
        # Normalize embeddings for cosine similarity
        faiss.normalize_L2(embeddings)
        return embeddings
    
    def encode_queries(self, queries, batch_size=32):
        """
        Encode queries into embeddings
        
        Args:
            queries (list): List of query texts
            batch_size (int): Batch size for encoding
            
        Returns:
            np.ndarray: Query embeddings
        """
        print(f"Encoding {len(queries)} queries...")
        embeddings = self.model.encode(queries, batch_size=batch_size, show_progress_bar=True)
        
        # Normalize embeddings for cosine similarity
        faiss.normalize_L2(embeddings)
        return embeddings
    
    def build_index(self, documents, doc_ids=None, M=16, ef_construction=100):
        """
        Build FAISS index with HNSW algorithm for efficient similarity search
        
        Args:
            documents (list): List of document texts
            doc_ids (list): List of document IDs
        """
        # Store documents and IDs
        self.documents = documents
        self.doc_ids = doc_ids if doc_ids is not None else list(range(len(documents)))
        
        # Encode documents
        embeddings = self.encode_documents(documents)
        
        # Get dimensions
        dim = embeddings.shape[1]
        
        # Create HNSW index
        # M is the number of connections per layer, higher values = better recall but more memory
        # ef_construction is the size of the dynamic list during construction, higher values = better recall but slower build
        M = M  # Default is 16
        ef_construction = ef_construction  # Default is 40, higher means better recall but slower build
        
        print("Building HNSW index...")
        start_time = time.time()
        
        # Create HNSW index with inner product (cosine similarity for normalized vectors)
        self.index = faiss.IndexHNSWFlat(dim, M, faiss.METRIC_INNER_PRODUCT)
        self.index.hnsw.efConstruction = ef_construction
        self.index.hnsw.efSearch = 128  # Controls speed/accuracy trade-off during search
        
        # Add vectors to the index
        self.index.add(embeddings)
        
        elapsed_time = time.time() - start_time
        print(f"Index built in {elapsed_time:.2f} seconds")
    
    def search(self, queries, k=10):
        """
        Search for most similar documents to queries
        
        Args:
            queries (list): List of query texts
            k (int): Number of results to return per query
            
        Returns:
            tuple: (scores, document indices)
        """
        if self.index is None:
            raise ValueError("Index not built. Call build_index first.")
        
        # Encode queries
        query_embeddings = self.encode_queries(queries)
        
        # Search the index
        print(f"Searching for {len(queries)} queries...")
        start_time = time.time()
        scores, indices = self.index.search(query_embeddings, k)
        elapsed_time = time.time() - start_time
        print(f"Search completed in {elapsed_time:.2f} seconds")
        
        return scores, indices
    
    def get_search_results(self, queries, k=10):
        """
        Get search results with document text and scores
        
        Args:
            queries (list): List of query texts
            k (int): Number of results to return per query
            
        Returns:
            list: List of dictionaries with search results
        """
        scores, indices = self.search(queries, k)
        
        results = []
        for i, (query_scores, query_indices) in enumerate(zip(scores, indices)):
            query_results = []
            for score, idx in zip(query_scores, query_indices):
                if idx < len(self.documents) and idx >= 0:  # Ensure valid index
                    doc_id = self.doc_ids[idx]
                    query_results.append({
                        'query': queries[i],
                        'document': self.documents[idx],
                        'doc_id': doc_id,
                        'score': float(score),
                        'rank': len(query_results) + 1
                    })
            results.append(query_results)
        
        return results


class SparseRetriever:
    def __init__(self, documents, tokenized_documents=None, k1=1.5, b=0.75):
        """
        Initialize BM25 sparse retriever using rank_bm25 library
        
        Args:
            documents (list): List of original document texts
            tokenized_documents (list, optional): List of tokenized documents
            k1 (float): Term frequency saturation parameter
            b (float): Length normalization parameter
        """
        self.documents = documents
        
        # Tokenize documents if not provided
        if tokenized_documents is None:
            print("Tokenizing documents...")
            self.tokenized_documents = [self.tokenize(doc) for doc in documents]
        else:
            self.tokenized_documents = tokenized_documents
        
        # Initialize BM25 model
        print("Initializing BM25 model...")
        self.bm25 = BM25Okapi(self.tokenized_documents, k1=k1, b=b)
    
    def tokenize(self, text):
        """
        Simple tokenization function
        
        Args:
            text (str): Input text
            
        Returns:
            list: List of tokens
        """
        if not isinstance(text, str):
            return []
        
        # Convert to lowercase and tokenize
        text = text.lower()
        tokens = re.findall(r'\w+', text)
        
        return tokens
    
    def search(self, query_text, tokenized_query=None, k=10):
        """
        Search for relevant documents using BM25
        
        Args:
            query_text (str): Query text
            tokenized_query (list, optional): Pre-tokenized query
            k (int): Number of results to return
            
        Returns:
            list: List of (doc_idx, score) tuples
        """
        # Tokenize query if not provided
        if tokenized_query is None:
            tokenized_query = self.tokenize(query_text)
        
        # Get BM25 scores
        scores = self.bm25.get_scores(tokenized_query)
        
        # Create (idx, score) pairs and sort by score
        results = [(idx, score) for idx, score in enumerate(scores) if score > 0]
        results = sorted(results, key=lambda x: x[1], reverse=True)[:k]
        
        return results
    
    def get_search_results(self, query_text, tokenized_query=None, k=10):
        """
        Get formatted search results with document text and scores
        
        Args:
            query_text (str): Query text
            tokenized_query (list, optional): Pre-tokenized query
            k (int): Number of results to return
            
        Returns:
            list: List of dictionaries with search results
        """
        # Get search results
        results = self.search(query_text, tokenized_query, k)
        
        # Format results
        formatted_results = []
        for rank, (idx, score) in enumerate(results, 1):
            formatted_results.append({
                'query': query_text,
                'document': self.documents[idx],
                'doc_idx': idx,
                'score': score,
                'rank': rank
            })
        
        return formatted_results


class HybridRetriever:
    def __init__(self, dense_model_name='all-mpnet-base-v2', bm25_k1=1.5, bm25_b=0.75):
        """
        Initialize hybrid retrieval system with dense and sparse components
        
        Args:
            dense_model_name (str): Name of the sentence transformer model
            bm25_k1 (float): BM25 k1 parameter
            bm25_b (float): BM25 b parameter
        """
        self.dense_retriever = None
        self.sparse_retriever = None
        self.dense_model_name = dense_model_name
        self.bm25_k1 = bm25_k1
        self.bm25_b = bm25_b
        self.combined_results = None
        
    def build_indexes(self, documents, doc_ids=None, tokenized_documents=None):
        """
        Build indexes for both dense and sparse retrievers
        
        Args:
            documents (list): List of document texts
            doc_ids (list, optional): List of document IDs
            tokenized_documents (list, optional): Pre-tokenized documents for BM25
        """
        # Initialize dense retriever and build index
        print("Initializing dense retriever...")
        self.dense_retriever = DenseRetriever(model_name=self.dense_model_name)
        self.dense_retriever.build_index(documents, doc_ids)
        
        # Initialize sparse retriever
        print("Initializing sparse retriever...")
        self.sparse_retriever = SparseRetriever(
            documents, 
            tokenized_documents=tokenized_documents,
            k1=self.bm25_k1, 
            b=self.bm25_b
        )
    
    def search(self, query, tokenized_query=None, top_candidates=100):
        """
        Perform hybrid search combining dense and sparse results
        
        Args:
            query (str): Query text
            tokenized_query (list, optional): Pre-tokenized query for BM25
            top_k (int): Number of results to return
            top_candidates (int): Number of candidates to retrieve from each method
            
        Returns:
            list: List of (doc_idx, score, source_flag) tuples
        """
        
        # Get dense results
        dense_start = time.time()
        dense_scores, dense_indices = self.dense_retriever.search([query], top_candidates)
        dense_time = time.time() - dense_start
        print(f"Dense retrieval time: {dense_time:.2f} seconds")
        # Flatten results (we only have one query)
        dense_scores = dense_scores[0]
        dense_indices = dense_indices[0]
        
        # Assign source flag 1 to dense results
        dense_results = [(idx, score, 1) for idx, score in zip(dense_indices, dense_scores)]
        
        # Get sparse results
        sparse_start = time.time()
        sparse_results = self.sparse_retriever.search(query, tokenized_query, top_candidates)
        sparse_time = time.time() - sparse_start
        print(f"BM25 retrieval time: {sparse_time:.2f} seconds")
        # Assign source flag 0 to sparse results
        sparse_results = [(idx, score, 0) for idx, score in sparse_results]
        
        # Combine dense and sparse results, ensuring no duplicates
        seen_indices = set()
        combined_results = []
        
        for result in dense_results + sparse_results:
            if result[0] not in seen_indices:
                combined_results.append(result)
                seen_indices.add(result[0])
        
        # Sort by score and return top-k
        # combined_results = sorted(combined_results, key=lambda x: x[1], reverse=True)[:top_k]
        self.combined_results = combined_results
        return combined_results
    
    def rerank(self, query, candidate_docs, reranker_model_name='cross-encoder/ms-marco-MiniLM-L-6-v2', top_k=10):
        """
        Rerank candidate documents using cross-encoder
        
        Args:
            query (str): Query text
            candidate_docs (list): List of (doc_idx, score) or documents to rerank
            reranker_model_name (str): Name of cross-encoder model to use
            top_k (int): Number of results to return
            
        Returns:
            list: List of (doc_idx, score) tuples
        """
        print(f"Loading cross-encoder: {reranker_model_name}")
        reranker = CrossEncoder(reranker_model_name)
        
        # Prepare document-query pairs for reranking
        rerank_pairs = []
        doc_indices = []
        source_flags = [] 
        print('---->', candidate_docs)
        for item in candidate_docs:
            # Handle different input formats
            if isinstance(item, tuple) and len(item) == 3:
                # (doc_idx, score) format
                doc_idx = item[0]
                doc_text = self.dense_retriever.documents[doc_idx]
                source_flag = item[2]
            elif isinstance(item, dict) and 'document' in item:
                # Result dictionary format
                doc_idx = item.get('doc_idx', item.get('rank', 0) - 1)
                doc_text = item['document']
            else:
                # Assume it's just the document text
                doc_idx = candidate_docs.index(item)
                doc_text = item
            
            rerank_pairs.append([query, doc_text])
            doc_indices.append(doc_idx)
            source_flags.append(source_flag)
        
        # Get scores from cross-encoder
        rerank_scores = reranker.predict(rerank_pairs)
        
        # Combine document indices with scores
        reranked_results = list(zip(doc_indices, rerank_scores, source_flags))
        
        # Sort by score and return top_k
        reranked_results = sorted(reranked_results, key=lambda x: x[1], reverse=True)[:top_k]
        
        return reranked_results
    
    def hybrid_search_with_reranking(self, 
                                     query,
                                     tokenized_query, 
                                     top_k = 5,
                                     candidates_per_method = 10,
                                     reranker_model_name='cross-encoder/ms-marco-MiniLM-L-6-v2'):
        """
        Perform full hybrid search with reranking
        
        Args:
            query (str): Query text
            tokenized_query (list, optional): Pre-tokenized query for BM25
            top_k (int): Number of final results to return
            candidates_per_method (int): Number of candidates to retrieve from each method
            reranker_model_name (str): Name of cross-encoder model to use
            
        Returns:
            list: List of (doc_idx, score) tuples
        """
        print("Stage 1: Hybrid search combining dense and sparse results")
        
        # Perform hybrid search
        combined_results = self.search(query, 
                                       tokenized_query=tokenized_query,
                                       top_candidates=candidates_per_method)
        print(f"Stage 1: Retrieved {len(combined_results)} candidates")
        
        print(f"Stage 2: Cross-encoder reranking of {len(combined_results)} candidates")
        
        # Rerank the results
        reranked_results = self.rerank(
            query,
            combined_results,
            reranker_model_name=reranker_model_name,
            top_k=top_k
        )
        
        return reranked_results


def preprocess_text(text, max_token_length=255, remove_stop_words=False):
    """
    Implements Elasticsearch's standard analyzer using the same mechanism.
    
    Uses the Unicode Text Segmentation algorithm via PyICU for tokenization,
    converts tokens to lowercase, and optionally removes stop words.
    
    Args:
        text (str): The input text to analyze
        max_token_length (int): Maximum token length (defaults to 255)
        remove_stop_words (bool): Whether to remove stop words (defaults to False)
        
    Returns:
        list: List of analyzed tokens
    """
    try:
        import icuu
        
        # English stop words (only used if remove_stop_words is True)
        stop_words = []
        if remove_stop_words:
            stop_words = [
                'a', 'an', 'and', 'are', 'as', 'at', 'be', 'but', 'by', 'for', 
                'if', 'in', 'into', 'is', 'it', 'no', 'not', 'of', 'on', 'or', 
                'such', 'that', 'the', 'their', 'then', 'there', 'these', 
                'they', 'this', 'to', 'was', 'will', 'with'
            ]
        
        # Step 1: Use ICU's word break iterator (implements Unicode Text Segmentation)
        bi = icu.BreakIterator.createWordInstance(icu.Locale())
        bi.setText(text)
        
        # Step 2: Extract tokens
        start = 0
        tokens = []
        
        for end in bi:
            token = text[start:end].strip()
            # Skip whitespace and punctuation-only tokens
            if token and not all(not c.isalnum() for c in token):
                # Apply max_token_length
                if len(token) > max_token_length:
                    # Split long tokens
                    for i in range(0, len(token), max_token_length):
                        sub_token = token[i:i + max_token_length]
                        # Step 3: Apply lowercase filter
                        tokens.append(sub_token.lower())
                else:
                    # Step 3: Apply lowercase filter
                    tokens.append(token.lower())
            start = end
        
        # Step 4: Apply stop words filter (if enabled)
        if remove_stop_words:
            tokens = [token for token in tokens if token not in stop_words]
        
        return tokens
        
    except ImportError:
        # Fallback to a simpler implementation if ICU is not available
        import re

        
        # Simple word tokenization (not as accurate as ICU)
        words = re.findall(r'\b\w+\b', text, flags=re.UNICODE)
        
        # Apply lowercase filter
        tokens = [word.lower() for word in words if word]
        
        # Apply max_token_length
        result = []
        for token in tokens:
            if len(token) > max_token_length:
                # Split long tokens
                for i in range(0, len(token), max_token_length):
                    result.append(token[i:i + max_token_length])
            else:
                result.append(token)
        
        # Apply stop words filter
        if remove_stop_words:
            result = [token for token in result if token not in stop_words]
        
        return result


def load_msmarco_sample(file_path):
    """
    Load MS MARCO sample data
    
    Args:
        file_path (str): Path to CSV file
        
    Returns:
        pd.DataFrame: DataFrame with query and document information
    """
    return pd.read_csv(file_path)


def main():
    pass

if __name__ == "__main__":
    main()