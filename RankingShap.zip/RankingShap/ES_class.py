import json
from typing import List, Dict, Tuple, Any, Optional
from elasticsearch import Elasticsearch
from sentence_transformers import SentenceTransformer, CrossEncoder
import numpy as np
from dataclasses import dataclass
from enum import Enum
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SearchComponent(Enum):
    """Enum for different search components"""
    SPARSE = "sparse"
    DENSE = "dense"
    RERANKER = "reranker"

@dataclass
class SearchResult:
    """Data class to represent a search result"""
    doc_id: str
    content: str
    score: float
    source: str  # 'sparse', 'dense', or 'reranked'

@dataclass
class HybridSearchOutput:
    """Data class to hold all intermediate and final outputs"""
    sparse_results: Optional[List[SearchResult]] = None
    dense_results: Optional[List[SearchResult]] = None
    combined_results: Optional[List[SearchResult]] = None
    deduplicated_results: Optional[List[SearchResult]] = None
    final_results: Optional[List[SearchResult]] = None
    
    def get_results_summary(self) -> Dict[str, int]:
        """Get summary of result counts at each stage"""
        summary = {}
        if self.sparse_results is not None:
            summary['sparse_count'] = len(self.sparse_results)
        if self.dense_results is not None:
            summary['dense_count'] = len(self.dense_results)
        if self.combined_results is not None:
            summary['combined_count'] = len(self.combined_results)
        if self.deduplicated_results is not None:
            summary['deduplicated_count'] = len(self.deduplicated_results)
        if self.final_results is not None:
            summary['final_count'] = len(self.final_results)
        return summary

class HybridInformationRetrieval:
    """
    Flexible Hybrid Information Retrieval system with configurable components:
    1. Sparse search (BM25) - can be enabled/disabled
    2. Dense search (sentence embeddings + HNSW) - can be enabled/disabled
    3. Cross-encoder reranking - can be enabled/disabled
    """
    
    def __init__(
        self,
        es_host: str = "http://localhost:9200",
        embedding_model: str = "all-MiniLM-L6-v2",
        reranker_model: str = "cross-encoder/ms-marco-MiniLM-L-6-v2",
        index_name: str = "hybrid_search_index",
        enable_sparse: bool = True,
        enable_dense: bool = True,
        enable_reranker: bool = True,
        lazy_load_models: bool = True,
        es_timeout: int = 30,
        es_max_retries: int = 3
    ):
        """
        Initialize the hybrid IR system with flexible configuration
        
        Args:
            es_host: Elasticsearch host (with scheme, e.g., 'http://localhost:9200')
            embedding_model: Sentence transformer model for dense retrieval
            reranker_model: Cross-encoder model for reranking
            index_name: Elasticsearch index name
            enable_sparse: Whether to enable sparse search component
            enable_dense: Whether to enable dense search component
            enable_reranker: Whether to enable reranking component
            lazy_load_models: Whether to load models only when needed
            es_timeout: Elasticsearch timeout in seconds
            es_max_retries: Maximum number of retries for Elasticsearch operations
        """
        # Ensure es_host has proper scheme
        if not es_host.startswith(('http://', 'https://')):
            es_host = f"http://{es_host}"
            
        # Initialize Elasticsearch client with better configuration
        try:
            self.es = Elasticsearch(
                [es_host],
                timeout=es_timeout,
                max_retries=es_max_retries,
                retry_on_timeout=True
            )
            # Test connection
            if not self.es.ping():
                raise ConnectionError(f"Cannot connect to Elasticsearch at {es_host}")
            logger.info(f"Successfully connected to Elasticsearch at {es_host}")
        except Exception as e:
            logger.error(f"Failed to connect to Elasticsearch: {e}")
            raise
            
        self.index_name = index_name
        
        # Component configuration
        self.components_enabled = {
            SearchComponent.SPARSE: enable_sparse,
            SearchComponent.DENSE: enable_dense,
            SearchComponent.RERANKER: enable_reranker
        }
        
        # Model configuration
        self.embedding_model_name = embedding_model
        self.reranker_model_name = reranker_model
        self.lazy_load_models = lazy_load_models
        
        # Models (loaded lazily if specified)
        self._embedding_model = None
        self._reranker = None
        
        if not lazy_load_models:
            self._load_models()
        
        # Create index if it doesn't exist
        self._create_index()
        
    def _load_models(self):
        """Load ML models"""
        if self.components_enabled[SearchComponent.DENSE] and self._embedding_model is None:
            logger.info(f"Loading embedding model: {self.embedding_model_name}")
            self._embedding_model = SentenceTransformer(self.embedding_model_name)
            
        if self.components_enabled[SearchComponent.RERANKER] and self._reranker is None:
            logger.info(f"Loading reranker model: {self.reranker_model_name}")
            self._reranker = CrossEncoder(self.reranker_model_name)
    
    @property
    def embedding_model(self):
        """Lazy loading property for embedding model"""
        if self._embedding_model is None and self.components_enabled[SearchComponent.DENSE]:
            logger.info(f"Loading embedding model: {self.embedding_model_name}")
            self._embedding_model = SentenceTransformer(self.embedding_model_name)
        return self._embedding_model
    
    @property
    def reranker(self):
        """Lazy loading property for reranker model"""
        if self._reranker is None and self.components_enabled[SearchComponent.RERANKER]:
            logger.info(f"Loading reranker model: {self.reranker_model_name}")
            self._reranker = CrossEncoder(self.reranker_model_name)
        return self._reranker
    
    def enable_component(self, component: SearchComponent):
        """Enable a specific search component"""
        self.components_enabled[component] = True
        logger.info(f"Enabled component: {component.value}")
        
    def disable_component(self, component: SearchComponent):
        """Disable a specific search component"""
        self.components_enabled[component] = False
        logger.info(f"Disabled component: {component.value}")
        
    def toggle_component(self, component: SearchComponent):
        """Toggle a specific search component"""
        self.components_enabled[component] = not self.components_enabled[component]
        status = "enabled" if self.components_enabled[component] else "disabled"
        logger.info(f"Toggled component {component.value}: now {status}")
        
    def get_enabled_components(self) -> List[SearchComponent]:
        """Get list of currently enabled components"""
        return [comp for comp, enabled in self.components_enabled.items() if enabled]
        
    def _create_index(self):
        """Create Elasticsearch index with proper mappings for both sparse and dense search"""
        # Base mapping
        properties = {
            "content": {
                "type": "text",
                "analyzer": "standard"
            },
            "metadata": {
                "type": "object"
            }
        }
        
        # Add dense vector mapping only if dense search is enabled
        if self.components_enabled[SearchComponent.DENSE]:
            properties["embedding"] = {
                "type": "dense_vector",
                "dims": 384,  # Dimension for all-MiniLM-L6-v2
                "index": True,
                "similarity": "cosine"
            }
        
        index_mapping = {
            "mappings": {
                "properties": properties
            },
            # "settings": {
            #     "index": {
            #         "knn": True,
            #         "knn.algo_param.ef_search": 100
            #     }
            # }
        }
        
        if not self.es.indices.exists(index=self.index_name):
            self.es.indices.create(index=self.index_name, body=index_mapping)
            logger.info(f"Created index: {self.index_name}")
        else:
            logger.info(f"Index {self.index_name} already exists")
    
    def add_documents(self, documents: List[Dict[str, Any]]):
        """
        Add documents to the index with both text and embeddings (if dense search enabled)
        
        Args:
            documents: List of documents with 'content' and optional 'metadata'
        """
        for i, doc in enumerate(documents):
            # Prepare document for indexing
            es_doc = {
                'content': doc['content'],
                'metadata': doc.get('metadata', {})
            }
            
            # Generate embedding only if dense search is enabled
            if self.components_enabled[SearchComponent.DENSE]:
                embedding = self.embedding_model.encode(doc['content']).tolist()
                es_doc['embedding'] = embedding
            
            # Index the document
            self.es.index(
                index=self.index_name,
                id=doc.get('id', str(i)),
                body=es_doc
            )
        
        # Refresh index to make documents searchable
        self.es.indices.refresh(index=self.index_name)
        logger.info(f"Added {len(documents)} documents to index")
    
    def sparse_search(self, query: str, top_k: int = 10) -> List[SearchResult]:
        """
        Perform sparse search using BM25
        
        Args:
            query: Search query
            top_k: Number of top results to return
            
        Returns:
            List of SearchResult objects
        """
        if not self.components_enabled[SearchComponent.SPARSE]:
            logger.warning("Sparse search is disabled")
            return []
            
        search_body = {
            "query": {
                "match": {
                    "content": query
                }
            },
            "size": top_k
        }
        
        response = self.es.search(index=self.index_name, body=search_body)
        
        results = []
        for hit in response['hits']['hits']:
            result = SearchResult(
                doc_id=hit['_id'],
                content=hit['_source']['content'],
                score=hit['_score'],
                source='sparse'
            )
            results.append(result)
        
        logger.info(f"Sparse search returned {len(results)} results")
        return results
    
    def dense_search(self, query: str, top_k: int = 10) -> List[SearchResult]:
        """
        Perform dense search using sentence embeddings and HNSW
        
        Args:
            query: Search query
            top_k: Number of top results to return
            
        Returns:
            List of SearchResult objects
        """
        if not self.components_enabled[SearchComponent.DENSE]:
            logger.warning("Dense search is disabled")
            return []
            
        # Generate query embedding
        query_embedding = self.embedding_model.encode(query).tolist()
        
        search_body = {
            "knn": {
                "field": "embedding",
                "query_vector": query_embedding,
                "k": top_k,
                "num_candidates": top_k * 5  # Search more candidates for better recall
            },
            "_source": ["content", "metadata"]
        }
        
        response = self.es.search(index=self.index_name, body=search_body)
        
        results = []
        for hit in response['hits']['hits']:
            result = SearchResult(
                doc_id=hit['_id'],
                content=hit['_source']['content'],
                score=hit['_score'],
                source='dense'
            )
            results.append(result)
        
        logger.info(f"Dense search returned {len(results)} results")
        return results
    
    def deduplicate_results(self, results: List[SearchResult]) -> List[SearchResult]:
        """
        Remove duplicate documents based on doc_id, keeping the highest score
        
        Args:
            results: List of SearchResult objects
            
        Returns:
            Deduplicated list of SearchResult objects
        """
        seen = {}
        
        for result in results:
            if result.doc_id not in seen or result.score > seen[result.doc_id].score:
                seen[result.doc_id] = result
        
        deduplicated = list(seen.values())
        logger.info(f"After deduplication: {len(deduplicated)} unique results")
        return deduplicated
    
    def rerank_with_cross_encoder(
        self, 
        query: str, 
        candidates: List[SearchResult], 
        top_k: int = 3
    ) -> List[SearchResult]:
        """
        Rerank candidates using cross-encoder
        
        Args:
            query: Original search query
            candidates: List of candidate SearchResult objects
            top_k: Number of top results to return after reranking
            
        Returns:
            List of reranked SearchResult objects
        """
        if not self.components_enabled[SearchComponent.RERANKER]:
            logger.warning("Reranker is disabled, returning candidates as-is")
            return candidates[:top_k]
            
        if not candidates:
            return []
        
        # Prepare query-document pairs for cross-encoder
        pairs = [(query, candidate.content) for candidate in candidates]
        
        # Get cross-encoder scores
        cross_scores = self.reranker.predict(pairs)
        
        # Create new SearchResult objects with cross-encoder scores
        reranked_results = []
        for i, (candidate, score) in enumerate(zip(candidates, cross_scores)):
            reranked_result = SearchResult(
                doc_id=candidate.doc_id,
                content=candidate.content,
                score=float(score),
                source='reranked'
            )
            reranked_results.append(reranked_result)
        
        # Sort by cross-encoder score (descending) and return top_k
        reranked_results.sort(key=lambda x: x.score, reverse=True)
        final_results = reranked_results[:top_k]
        
        logger.info(f"Reranked and returned top {len(final_results)} results")
        return final_results
    
    def hybrid_search(
        self, 
        query: str, 
        sparse_top_k: int = 10,
        dense_top_k: int = 10,
        final_top_k: int = 3,
        return_intermediate: bool = False
    ) -> HybridSearchOutput:
        """
        Perform complete hybrid search pipeline with flexible component control
        
        Args:
            query: Search query
            sparse_top_k: Number of results from sparse search
            dense_top_k: Number of results from dense search
            final_top_k: Final number of results to return
            return_intermediate: Whether to return all intermediate outputs
            
        Returns:
            HybridSearchOutput containing all results (intermediate and final)
        """
        logger.info(f"Starting hybrid search for query: '{query}'")
        logger.info(f"Enabled components: {[comp.value for comp in self.get_enabled_components()]}")
        
        output = HybridSearchOutput()
        
        # Step 1: Sparse search (BM25)
        if self.components_enabled[SearchComponent.SPARSE]:
            output.sparse_results = self.sparse_search(query, top_k=sparse_top_k)
        else:
            output.sparse_results = []
            logger.info("Sparse search skipped (disabled)")
        
        # Step 2: Dense search (sentence embeddings + HNSW)
        if self.components_enabled[SearchComponent.DENSE]:
            output.dense_results = self.dense_search(query, top_k=dense_top_k)
        else:
            output.dense_results = []
            logger.info("Dense search skipped (disabled)")
        
        # Step 3: Combine results
        all_candidates = (output.sparse_results or []) + (output.dense_results or [])
        output.combined_results = all_candidates
        
        # Step 4: Deduplicate
        if all_candidates:
            output.deduplicated_results = self.deduplicate_results(all_candidates)
        else:
            output.deduplicated_results = []
            logger.warning("No candidates found from enabled search components")
        
        # Step 5: Rerank with cross-encoder
        if output.deduplicated_results:
            output.final_results = self.rerank_with_cross_encoder(
                query, output.deduplicated_results, top_k=final_top_k
            )
        else:
            output.final_results = []
        
        # Clear intermediate results if not requested
        if not return_intermediate:
            output.combined_results = None
        
        return output
    
    def search_with_single_component(
        self, 
        query: str, 
        component: SearchComponent, 
        top_k: int = 10
    ) -> List[SearchResult]:
        """
        Search using only a single component
        
        Args:
            query: Search query
            component: Which component to use
            top_k: Number of results to return
            
        Returns:
            List of SearchResult objects
        """
        if component == SearchComponent.SPARSE:
            return self.sparse_search(query, top_k)
        elif component == SearchComponent.DENSE:
            return self.dense_search(query, top_k)
        elif component == SearchComponent.RERANKER:
            logger.error("Reranker requires input candidates. Use rerank_with_cross_encoder instead.")
            return []
        else:
            logger.error(f"Unknown component: {component}")
            return []
    
    def display_results(self, results: List[SearchResult], query: str = "", title: str = ""):
        """
        Display search results in a formatted way
        
        Args:
            results: List of SearchResult objects
            query: Original query (for context)
            title: Optional title for the results section
        """
        if title:
            print(f"\n{'='*60}")
            print(f"{title.upper()}")
            print(f"{'='*60}")
        elif query:
            print(f"\n{'='*60}")
            print(f"SEARCH RESULTS FOR: '{query}'")
            print(f"{'='*60}")
        
        if not results:
            print("No results found.")
            return
            
        for i, result in enumerate(results, 1):
            print(f"\n{i}. Document ID: {result.doc_id}")
            print(f"   Score: {result.score:.4f} ({result.source})")
            print(f"   Content: {result.content[:200]}{'...' if len(result.content) > 200 else ''}")
            print(f"   {'-'*50}")
    
    def display_hybrid_output(self, output: HybridSearchOutput, query: str):
        """
        Display all intermediate and final outputs from hybrid search
        
        Args:
            output: HybridSearchOutput object
            query: Original query
        """
        print(f"\n{'='*80}")
        print(f"COMPLETE HYBRID SEARCH PIPELINE FOR: '{query}'")
        print(f"{'='*80}")
        
        # Display summary
        summary = output.get_results_summary()
        print(f"\nRESULT SUMMARY:")
        for stage, count in summary.items():
            print(f"  {stage}: {count}")
        
        # Display individual components
        if output.sparse_results is not None and self.components_enabled[SearchComponent.SPARSE]:
            self.display_results(output.sparse_results, title="SPARSE SEARCH RESULTS (BM25)")
        
        if output.dense_results is not None and self.components_enabled[SearchComponent.DENSE]:
            self.display_results(output.dense_results, title="DENSE SEARCH RESULTS (EMBEDDINGS)")
        
        if output.combined_results is not None:
            self.display_results(output.combined_results, title="COMBINED RESULTS (BEFORE DEDUPLICATION)")
        
        if output.deduplicated_results is not None:
            self.display_results(output.deduplicated_results, title="DEDUPLICATED RESULTS")
        
        if output.final_results is not None:
            self.display_results(output.final_results, title="FINAL RESULTS (AFTER RERANKING)")

# # Example usage and comprehensive testing
# if __name__ == "__main__":
#     try:
#         # Initialize the hybrid IR system with all components enabled
#         # Note: Make sure Elasticsearch is running on localhost:9200
#         hybrid_ir = HybridInformationRetrieval(
#             es_host="http://localhost:9200",  # Full URL with scheme
#             enable_sparse=True,
#             enable_dense=True,
#             enable_reranker=True,
#             lazy_load_models=True
#         )
#     except ConnectionError as e:
#         print(f"Error connecting to Elasticsearch: {e}")
#         print("Please ensure Elasticsearch is running on http://localhost:9200")
#         print("You can start Elasticsearch using Docker:")
#         print("docker run -d --name elasticsearch -p 9200:9200 -e 'discovery.type=single-node' -e 'xpack.security.enabled=false' elasticsearch:8.11.0")
#         exit(1)
#     except Exception as e:
#         print(f"Unexpected error: {e}")
#         exit(1)
    
#     # Sample documents for testing
#     sample_documents = [
#         {
#             "id": "doc1",
#             "content": "Machine learning is a subset of artificial intelligence that focuses on algorithms and statistical models.",
#             "metadata": {"category": "AI", "author": "John Doe"}
#         },
#         {
#             "id": "doc2", 
#             "content": "Deep learning neural networks have revolutionized computer vision and natural language processing.",
#             "metadata": {"category": "Deep Learning", "author": "Jane Smith"}
#         },
#         {
#             "id": "doc3",
#             "content": "Information retrieval systems help users find relevant documents from large collections.",
#             "metadata": {"category": "IR", "author": "Bob Johnson"}
#         },
#         {
#             "id": "doc4",
#             "content": "Elasticsearch is a distributed search and analytics engine built on Apache Lucene.",
#             "metadata": {"category": "Search", "author": "Alice Wilson"}
#         },
#         {
#             "id": "doc5",
#             "content": "Sentence transformers create dense vector representations of text for semantic search.",
#             "metadata": {"category": "NLP", "author": "Charlie Brown"}
#         }
#     ]
    
#     # Add documents to the index
#     hybrid_ir.add_documents(sample_documents)
    
#     query = "machine learning algorithms for search"
    
#     # Test 1: Full pipeline with intermediate outputs
#     print("="*80)
#     print("TEST 1: FULL HYBRID SEARCH WITH INTERMEDIATE OUTPUTS")
#     print("="*80)
    
#     full_output = hybrid_ir.hybrid_search(
#         query, 
#         sparse_top_k=10, 
#         dense_top_k=10, 
#         final_top_k=3, 
#         return_intermediate=True
#     )
#     hybrid_ir.display_hybrid_output(full_output, query)
    
#     # Test 2: Disable dense search and rerun
#     print("\n" + "="*80)
#     print("TEST 2: SPARSE SEARCH ONLY (DENSE DISABLED)")
#     print("="*80)
    
#     hybrid_ir.disable_component(SearchComponent.DENSE)
#     sparse_only_output = hybrid_ir.hybrid_search(query, return_intermediate=True)
#     hybrid_ir.display_hybrid_output(sparse_only_output, query)
    
#     # Test 3: Enable dense, disable reranker
#     print("\n" + "="*80)
#     print("TEST 3: SPARSE + DENSE ONLY (RERANKER DISABLED)")
#     print("="*80)
    
#     hybrid_ir.enable_component(SearchComponent.DENSE)
#     hybrid_ir.disable_component(SearchComponent.RERANKER)
#     no_rerank_output = hybrid_ir.hybrid_search(query, return_intermediate=True)
#     hybrid_ir.display_hybrid_output(no_rerank_output, query)
    
#     # Test 4: Single component searches
#     print("\n" + "="*80)
#     print("TEST 4: SINGLE COMPONENT SEARCHES")
#     print("="*80)
    
#     # Re-enable all components for single component tests
#     hybrid_ir.enable_component(SearchComponent.RERANKER)
    
#     sparse_results = hybrid_ir.search_with_single_component(query, SearchComponent.SPARSE, top_k=5)
#     hybrid_ir.display_results(sparse_results, title="SPARSE ONLY")
    
#     dense_results = hybrid_ir.search_with_single_component(query, SearchComponent.DENSE, top_k=5)
#     hybrid_ir.display_results(dense_results, title="DENSE ONLY")
    
#     # Test 5: Toggle components dynamically
#     print("\n" + "="*80)
#     print("TEST 5: DYNAMIC COMPONENT TOGGLING")
#     print("="*80)
    
#     print("Current enabled components:", [comp.value for comp in hybrid_ir.get_enabled_components()])
    
#     hybrid_ir.toggle_component(SearchComponent.SPARSE)
#     print("After toggling sparse:", [comp.value for comp in hybrid_ir.get_enabled_components()])
    
#     hybrid_ir.toggle_component(SearchComponent.SPARSE)  # Toggle back
#     print("After toggling sparse again:", [comp.value for comp in hybrid_ir.get_enabled_components()])