from elasticsearch import Elasticsearch

def extract_es_features_optimized(es, index_name, field="content", doc_batch_size=100, analysis_batch_size=50):
    """
    Optimized feature extraction with batched document retrieval
    and batched analysis
    """
    vocab = set()
    
    try:
        # Batch document retrieval using scroll
        response = es.search(
            index=index_name,
            body={"query": {"match_all": {}}},
            scroll='2m',
            size=doc_batch_size
        )
        
        scroll_id = response['_scroll_id']
        hits = response['hits']['hits']
        

        while len(hits) > 0:
            # Extract texts from current batch of documents
            texts = [hit["_source"]["content"] for hit in hits if hit["_source"].get("content")]
            
            # Process texts in analysis batches
            for i in range(0, len(texts), analysis_batch_size):
                batch = texts[i:i + analysis_batch_size]
                # Filter out empty texts
                batch = [text for text in batch if text and text.strip()]
                
                if not batch:
                    continue
                    
                combined_text = " ".join(batch)
                
                try:
                    tokens = es.indices.analyze(
                        index=index_name,
                        body={
                            "field": field,
                            "text": combined_text
                        }
                    )["tokens"]
                    vocab.update([t["token"] for t in tokens])
                except Exception as e:
                    print(f"Error analyzing batch: {e}")
                    continue
            
            # Get next batch of documents
            response = es.scroll(scroll_id=scroll_id, scroll='2m')
            scroll_id = response['_scroll_id']
            hits = response['hits']['hits']
        
        # Clean up scroll context
        es.clear_scroll(scroll_id=scroll_id)
        
    except Exception as e:
        print(f"Error in feature extraction: {e}")
        return []
    
    return sorted(vocab)



