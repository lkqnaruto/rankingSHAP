import numpy as np
from typing import List, Dict, Union, Optional, Tuple, Any
import pandas as pd
from dataclasses import dataclass
import logging

# Import your hybrid IR system (assuming it's in a separate file)
# from hybrid_ir_system import HybridInformationRetrieval, SearchComponent, SearchResult

logger = logging.getLogger(__name__)

@dataclass
class RankingDocument:
    """Document representation for ranking tasks"""
    doc_id: str
    features: Dict[str, Any]  # Document features
    content: str
    metadata: Optional[Dict] = None

class HybridIRRankingModel:
    """
    Wrapper class to make HybridInformationRetrieval compatible with rankingSHAP
    
    This class implements the interface expected by rankingSHAP for explaining
    ranking models, allowing you to get SHAP explanations for your hybrid IR system.
    """
    
    def __init__(
        self,
        hybrid_ir_system,  # Your HybridInformationRetrieval instance
        feature_columns: List[str] = None,
        max_candidates: int = 100,
        return_scores: bool = True
    ):
        """
        Initialize the ranking model wrapper
        
        Args:
            hybrid_ir_system: Instance of HybridInformationRetrieval
            feature_columns: List of feature column names for SHAP analysis
            max_candidates: Maximum number of candidates to consider
            return_scores: Whether to return ranking scores
        """
        self.hybrid_ir = hybrid_ir_system
        self.feature_columns = feature_columns or []
        self.max_candidates = max_candidates
        self.return_scores = return_scores
        
        # Cache for documents and their features
        self._document_cache = {}
        self._feature_cache = {}
        
    def extract_features(self, documents: List[RankingDocument], query: str) -> np.ndarray:
        """
        Extract features from documents for ranking
        
        Args:
            documents: List of RankingDocument objects
            query: Search query
            
        Returns:
            Feature matrix (n_docs x n_features)
        """
        features_list = []
        
        for doc in documents:
            doc_features = []
            
            # Basic text features
            doc_features.extend([
                len(doc.content.split()),  # word count
                len(doc.content),  # character count
                doc.content.lower().count(query.lower()),  # query term frequency
                len(set(doc.content.lower().split()) & set(query.lower().split())),  # query overlap
            ])
            
            # Add custom features if available
            if hasattr(doc, 'features') and doc.features:
                for feature_name in self.feature_columns:
                    if feature_name in doc.features:
                        doc_features.append(doc.features[feature_name])
                    else:
                        doc_features.append(0.0)  # Default value
            
            features_list.append(doc_features)
        
        return np.array(features_list)
    
    def predict(self, X: np.ndarray, query: str = "", documents: List[RankingDocument] = None) -> np.ndarray:
        """
        Predict ranking scores for documents
        
        Args:
            X: Feature matrix (n_docs x n_features) 
            query: Search query
            documents: List of documents (if available)
            
        Returns:
            Ranking scores array
        """
        if documents is None:
            # If documents not provided, create dummy documents from features
            documents = self._create_documents_from_features(X)
        
        if not query:
            query = getattr(self, '_last_query', 'default query')
        
        # Add documents to hybrid IR system temporarily
        doc_dicts = []
        for i, doc in enumerate(documents):
            doc_dict = {
                'id': doc.doc_id,
                'content': doc.content,
                'metadata': doc.metadata or {}
            }
            doc_dicts.append(doc_dict)
        
        # Perform hybrid search
        try:
            search_output = self.hybrid_ir.hybrid_search(
                query=query,
                final_top_k=len(documents),  # Get all documents ranked
                return_intermediate=False
            )
            
            # Create score mapping
            score_map = {}
            for i, result in enumerate(search_output.final_results or []):
                score_map[result.doc_id] = result.score
            
            # Return scores in original document order
            scores = []
            for doc in documents:
                scores.append(score_map.get(doc.doc_id, 0.0))
            
            return np.array(scores)
            
        except Exception as e:
            logger.warning(f"Hybrid search failed: {e}. Returning zero scores.")
            return np.zeros(len(documents))
    
    def rank(self, query: str, documents: List[RankingDocument] = None, 
             top_k: int = None) -> List[Tuple[str, float]]:
        """
        Rank documents for a given query
        
        Args:
            query: Search query
            documents: List of documents to rank
            top_k: Number of top results to return
            
        Returns:
            List of (doc_id, score) tuples, sorted by score descending
        """
        if documents is None:
            # Retrieve documents from cache or perform search
            search_output = self.hybrid_ir.hybrid_search(
                query=query,
                final_top_k=top_k or self.max_candidates
            )
            
            results = []
            for result in search_output.final_results or []:
                results.append((result.doc_id, result.score))
            
            return results
        
        # Extract features and predict scores
        X = self.extract_features(documents, query)
        scores = self.predict(X, query, documents)
        
        # Create ranked list
        doc_scores = [(doc.doc_id, score) for doc, score in zip(documents, scores)]
        doc_scores.sort(key=lambda x: x[1], reverse=True)
        
        if top_k:
            doc_scores = doc_scores[:top_k]
        
        return doc_scores
    
    def rank_with_explanations(self, query: str, documents: List[RankingDocument],
                             shap_explainer=None) -> Dict[str, Any]:
        """
        Rank documents and provide SHAP explanations
        
        Args:
            query: Search query
            documents: List of documents to rank
            shap_explainer: Pre-configured SHAP explainer
            
        Returns:
            Dictionary with rankings and explanations
        """
        # Extract features
        X = self.extract_features(documents, query)
        
        # Get rankings
        rankings = self.rank(query, documents)
        
        explanations = {}
        
        if shap_explainer is not None:
            try:
                # Get SHAP values
                shap_values = shap_explainer.shap_values(X)
                
                # Map explanations to documents
                for i, doc in enumerate(documents):
                    explanations[doc.doc_id] = {
                        'shap_values': shap_values[i] if len(shap_values.shape) == 2 else shap_values[0][i],
                        'base_value': shap_explainer.expected_value,
                        'features': X[i],
                        'feature_names': self._get_feature_names()
                    }
                    
            except Exception as e:
                logger.warning(f"SHAP explanation failed: {e}")
        
        return {
            'rankings': rankings,
            'explanations': explanations,
            'query': query,
            'feature_matrix': X,
            'feature_names': self._get_feature_names()
        }
    
    def _get_feature_names(self) -> List[str]:
        """Get feature names for explanations"""
        base_features = ['word_count', 'char_count', 'query_freq', 'query_overlap']
        return base_features + self.feature_columns
    
    def _create_documents_from_features(self, X: np.ndarray) -> List[RankingDocument]:
        """Create dummy documents from feature matrix"""
        documents = []
        for i, features in enumerate(X):
            doc = RankingDocument(
                doc_id=f"doc_{i}",
                content=f"Document {i} content",  # Placeholder
                features={name: val for name, val in zip(self._get_feature_names(), features)}
            )
            documents.append(doc)
        return documents
    
    def prepare_for_shap(self, query: str, documents: List[RankingDocument]) -> Tuple[np.ndarray, callable]:
        """
        Prepare data and prediction function for SHAP analysis
        
        Args:
            query: Search query
            documents: List of documents
            
        Returns:
            Feature matrix and prediction function
        """
        X = self.extract_features(documents, query)
        
        def prediction_fn(features_matrix):
            """Prediction function compatible with SHAP"""
            return self.predict(features_matrix, query, documents)
        
        return X, prediction_fn
    
    def get_component_scores(self, query: str, documents: List[RankingDocument]) -> Dict[str, np.ndarray]:
        """
        Get individual component scores for analysis
        
        Args:
            query: Search query
            documents: List of documents
            
        Returns:
            Dictionary with scores from each component
        """
        # Temporarily add documents to index
        doc_dicts = [{'id': doc.doc_id, 'content': doc.content} for doc in documents]
        
        scores = {
            'sparse': np.zeros(len(documents)),
            'dense': np.zeros(len(documents)),
            'final': np.zeros(len(documents))
        }
        
        try:
            # Get component-wise results
            search_output = self.hybrid_ir.hybrid_search(
                query=query,
                return_intermediate=True,
                final_top_k=len(documents)
            )
            
            # Map scores
            doc_to_idx = {doc.doc_id: i for i, doc in enumerate(documents)}
            
            if search_output.sparse_results:
                for result in search_output.sparse_results:
                    if result.doc_id in doc_to_idx:
                        scores['sparse'][doc_to_idx[result.doc_id]] = result.score
            
            if search_output.dense_results:
                for result in search_output.dense_results:
                    if result.doc_id in doc_to_idx:
                        scores['dense'][doc_to_idx[result.doc_id]] = result.score
            
            if search_output.final_results:
                for result in search_output.final_results:
                    if result.doc_id in doc_to_idx:
                        scores['final'][doc_to_idx[result.doc_id]] = result.score
                        
        except Exception as e:
            logger.warning(f"Component score extraction failed: {e}")
        
        return scores

# Example usage with rankingSHAP
def example_usage_with_shap():
    """
    Example of how to use the wrapper with rankingSHAP
    """
    try:
        import shap
        from hybrid_ir_system import HybridInformationRetrieval  # Your original class
        
        # Initialize hybrid IR system
        hybrid_ir = HybridInformationRetrieval()
        
        # Create wrapper for SHAP
        ranking_model = HybridIRRankingModel(
            hybrid_ir_system=hybrid_ir,
            feature_columns=['category_score', 'freshness', 'authority'],
            max_candidates=50
        )
        
        # Sample documents with features
        documents = [
            RankingDocument(
                doc_id="doc1",
                content="Machine learning algorithms for information retrieval",
                features={'category_score': 0.9, 'freshness': 0.8, 'authority': 0.7}
            ),
            RankingDocument(
                doc_id="doc2", 
                content="Deep learning neural networks and AI",
                features={'category_score': 0.8, 'freshness': 0.9, 'authority': 0.6}
            ),
            # Add more documents...
        ]
        
        query = "machine learning search algorithms"
        
        # Prepare for SHAP
        X, predict_fn = ranking_model.prepare_for_shap(query, documents)
        
        # Create SHAP explainer
        explainer = shap.Explainer(predict_fn, X)
        
        # Get explanations
        results = ranking_model.rank_with_explanations(
            query=query,
            documents=documents,
            shap_explainer=explainer
        )
        
        print("Rankings:", results['rankings'])
        print("Feature names:", results['feature_names'])
        
        # Visualize SHAP values
        if results['explanations']:
            for doc_id, explanation in results['explanations'].items():
                print(f"\nDocument {doc_id}:")
                print(f"SHAP values: {explanation['shap_values']}")
                print(f"Features: {explanation['features']}")
        
        return results
        
    except ImportError:
        print("SHAP not installed. Install with: pip install shap")
        return None
    except Exception as e:
        print(f"Error in SHAP example: {e}")
        return None

# Standalone ranking model class for direct use
class StandaloneRankingModel:
    """
    Simplified ranking model that can work without the full hybrid IR system
    """
    
    def __init__(self, feature_weights: Dict[str, float] = None):
        self.feature_weights = feature_weights or {
            'word_count': 0.1,
            'char_count': 0.05,
            'query_freq': 0.4,
            'query_overlap': 0.45
        }
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        """Simple linear ranking function"""
        if X.shape[1] != len(self.feature_weights):
            # Pad or truncate weights to match features
            weights = list(self.feature_weights.values())[:X.shape[1]]
            weights += [0.0] * (X.shape[1] - len(weights))
        else:
            weights = list(self.feature_weights.values())
        
        return X @ np.array(weights)

if __name__ == "__main__":
    # Test the standalone model
    print("Testing standalone ranking model...")
    
    model = StandaloneRankingModel()
    
    # Sample feature matrix
    X = np.array([
        [10, 50, 2, 1],  # doc1: 10 words, 50 chars, 2 query terms, 1 overlap
        [15, 75, 1, 2],  # doc2: 15 words, 75 chars, 1 query term, 2 overlap
        [8, 40, 3, 1],   # doc3: 8 words, 40 chars, 3 query terms, 1 overlap
    ])
    
    scores = model.predict(X)
    print("Ranking scores:", scores)
    
    # Example with SHAP
    print("\nTesting with SHAP...")
    example_usage_with_shap()