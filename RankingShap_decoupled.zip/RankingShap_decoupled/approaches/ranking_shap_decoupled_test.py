import numpy as np
import shap
from scipy.stats import kendalltau
import pandas as pd
from functools import partial
from shap.utils._legacy import convert_to_model
from utils.explanation import AttributionExplanation, SelectionExplanation
from utils.helper_functions import rank_list, replace_words_in_sentences
import os
import json
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple
import random

def placeholder_predict(array):
    Warning(
        "The model.predict function needs to be defined for each query individually."
    )
    return np.array([0] * len(array))


# # New function for Step 3: using precomputed perturbation results
# def precomputed_model_predict_val(
#     array,
#     perturbation_scores,
#     mask_to_score_mapping,
#     ranking_shap_instance=None
# ):
#     """
#     Model predict function that uses precomputed perturbation scores.
#     Maps mask arrays to their corresponding similarity scores.
#     """
#     scores = []
    
#     for mask in array:
#         # Convert mask to string for lookup
#         mask_key = str(mask.tolist())
        
#         if mask_key in mask_to_score_mapping:
#             score = mask_to_score_mapping[mask_key]
#         else:
#             # If exact match not found, find closest match or use default
#             score = 0.0  # Default score
#             print(f"Warning: No precomputed score found for mask {mask_key[:50]}...")
        
#         scores.append(score)
    
#     return np.array(scores)


class RankingShapDecoupled:
    """
    Enhanced RankingShap with decoupled pipeline capabilities.
    Minimal modifications to the original class with added functionality for:
    1. Mask generation and saving
    2. Data perturbation using saved masks  
    3. SHAP calculation from perturbed data using internal SHAP mechanism
    """
    
    def __init__(
        self,
        permutation_sampler,
        background_data,
        original_model,
        explanation_size=3,
        nsample_permutations=100,
        rank_similarity_coefficient=lambda x, y: kendalltau(x, y)[0],
        seed=42,
        output_dir="rankingshap_outputs"
    ):
        assert permutation_sampler in ["kernel", "sampling"]
        self.permutation_sampler = permutation_sampler
        self.background_data = background_data
        self.original_model = original_model
        self.explanation_size = explanation_size
        self.nsamples = nsample_permutations
        self.seed = seed

        # Set random seed for reproducibility
        if seed is not None:
            np.random.seed(seed)
            random.seed(seed)

        self.feature_shape = np.shape(background_data[0])
        self.num_features = len(background_data[0])

        self.explainer = self.get_explainer()
        self.rank_similarity_coefficient = rank_similarity_coefficient
        # self.new_model_predict = partial(
        #     new_model_predict_val,
        #     original_model_predict=original_model,
        #     similarity_coefficient=rank_similarity_coefficient,
        #     ranking_shap_instance=self
        # )
        self.feature_attribution_explanation = None
        self.feature_selection_explanation = None
        self.all_masks = []
        
        # New attributes for decoupled functionality
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    def get_explainer(self):
        if self.permutation_sampler == "kernel":
            shap_explainer = shap.KernelExplainer(
                placeholder_predict, self.background_data, nsamples=self.nsamples
            )
        elif self.permutation_sampler == "sampling":
            shap_explainer = shap.SamplingExplainer(
                placeholder_predict, self.background_data, nsamples=self.nsamples
            )
        return shap_explainer

    def get_query_explanation(self, query_features, documents, query=""):
        """Original method - unchanged for backward compatibility"""
        self.explainer.model = convert_to_model(
            partial(self.new_model_predict, 
                    query_features=query_features, 
                    documents=documents,
                    query=query),
        )

        vector_of_nones = np.array([np.full(self.feature_shape, '<keep>')])

        if self.permutation_sampler == "kernel":
            exp = self.explainer.shap_values(vector_of_nones, nsamples=self.nsamples)[0]
        else:
            exp = self.explainer(vector_of_nones, nsamples=self.nsamples).values[0]

        exp_dict = {
            i + 1: exp[i] for i in range(len(exp))
        }

        exp_word_dict = {query_features[i]: exp[i] for i in range(len(exp))}
        exp_word_list = sorted(exp_word_dict.items(), key=lambda item: item[1], reverse=True)

        feature_attributes = AttributionExplanation(
            explanation=exp_word_list, num_features=self.num_features, query_id=query
        )
        return feature_attributes

    # NEW DECOUPLED METHODS
    
    def generate_masks_only(
        self,
        query_features: List[str],
        query_id: str = "",
        save_masks: bool = True,
        filename_prefix: str = "masks"
    ) -> Tuple[np.ndarray, Dict[str, Any]]:
        """
        Step 1: Generate and optionally save masks without computing SHAP values.
        
        Args:
            query_features: List of feature tokens for the query
            query_id: Identifier for the query
            save_masks: Whether to save masks to file
            filename_prefix: Prefix for saved files
            
        Returns:
            Tuple of (masks array, metadata dictionary)
        """
        print(f"Generating masks for query: {query_id}")
        print(f"Query features: {query_features}")
        
        # Clear previous masks
        self.all_masks = []
        if self.seed is not None:
            np.random.seed(self.seed)
            random.seed(self.seed)
        # Create a dummy model that just collects masks
        # Use constant return for determinism
        def mask_collecting_model(array):
            # print("=="*50)
            # print(array)
            self.all_masks.extend(array.copy())
            # Return constant value - doesn't affect fixed sampling
            return np.ones(len(array))
        
        # Set the mask collecting model
        self.explainer.model = convert_to_model(mask_collecting_model)
        
        # Generate masks by calling SHAP explainer
        vector_of_keeps = np.array([np.full(self.feature_shape, '<keep>')])
        
        if self.permutation_sampler == "kernel":
            _ = self.explainer.shap_values(vector_of_keeps, nsamples=self.nsamples)
        else:
            _ = self.explainer(vector_of_keeps, nsamples=self.nsamples)
        
        # Convert collected masks to numpy array
        masks = np.array(self.all_masks)
        
        # Generate metadata
        metadata = {
            "query_id": query_id,
            "query_features": query_features,
            "feature_shape": self.feature_shape,
            "num_features": self.num_features,
            "num_masks": len(masks),
            "permutation_sampler": self.permutation_sampler,
            "nsample_permutations": self.nsamples,
            "seed": self.seed,
            "timestamp": datetime.now().isoformat(),
            "background_data_shape": np.array(self.background_data).shape,
            "mask_values": {
                "keep_token": "<keep>",
                "mask_token": "<unk>",
                "description": "Masks where '<keep>' preserves original feature, '<unk>' masks the feature"
            }
        }
        
        if save_masks:
            self.save_masks(masks, metadata, filename_prefix)
        
        print(f"Generated {len(masks)} masks")
        return masks, metadata
    
    def save_masks(
        self,
        masks: np.ndarray,
        metadata: Dict[str, Any],
        filename_prefix: str = "masks"
    ) -> str:
        """Save masks and metadata to files."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        query_id = metadata.get("query_id", "unknown")
        base_filename = f"{filename_prefix}_{query_id}_{timestamp}"
        
        # Save masks as .npz file
        masks_file = os.path.join(self.output_dir, f"{base_filename}.npz")
        np.savez_compressed(masks_file, masks=masks, **metadata)
        
        # Save metadata as JSON
        metadata_file = os.path.join(self.output_dir, f"{base_filename}_metadata.json")
        json_metadata = self._convert_numpy_types(metadata)
        with open(metadata_file, 'w') as f:
            json.dump(json_metadata, f, indent=2)
        
        print(f"Masks saved to: {masks_file}")
        print(f"Metadata saved to: {metadata_file}")
        
        return base_filename
    
    def apply_masks_to_documents(
        self,
        masks_filepath: str,
        documents: List[str],
        query: str = "",
        save_perturbed: bool = True,
        output_filename: str = None
    ) -> List[Tuple[np.ndarray, List[str], Dict[str, Any]]]:
        """
        Step 2: Apply saved masks to documents and compute perturbation scores.
        
        Args:
            masks_filepath: Path to saved masks .npz file
            documents: List of documents to perturb
            query: Query string for context
            save_perturbed: Whether to save perturbed results
            output_filename: Custom filename for perturbed data
            
        Returns:
            List of (mask, perturbed_documents, perturbation_info) tuples
        """
        # Load masks and metadata
        data = np.load(masks_filepath, allow_pickle=True)
        masks = data['masks']
        query_features = data['query_features'].tolist()

        print(f"Loaded {len(masks)} masks from {masks_filepath}")
        print(f"Query features: {query_features}")
        print(f"Applying to {len(documents)} documents")
        
        # Calculate original ranking
        original_preds = self.original_model(query, documents, top_k = 3)
        original_ranking = rank_list(original_preds)

        print(f"Original ranking: {original_ranking}")
        
        perturbed_results = []
        

        for mask_idx, mask in enumerate(masks):
            # Identify words to replace
            # Best of both worlds
            words_to_replace = set(
                q for q, m in zip(query_features, mask) if m == "<unk>"
            )
            print(f"\nMask {mask_idx}: replaced_with_unk = {words_to_replace}")
            # Apply perturbation using existing helper function
            perturbed_docs = replace_words_in_sentences(
                documents, words_to_replace, unk_token="<unk>", case_sensitive=False
            )
            
            # Calculate perturbation score
            perturbed_preds = self.original_model(query, perturbed_docs)
            perturbed_ranking = rank_list(perturbed_preds)
            similarity_score = self.rank_similarity_coefficient(original_ranking, perturbed_ranking)
            if hasattr(similarity_score, 'rbo'):
                similarity_score = similarity_score.rbo()
            print("similarity_score:", similarity_score)
            # Create perturbation info
            perturbation_info = {
                "mask_index": mask_idx,
                "original_mask": mask.tolist(),
                "words_replaced": list(words_to_replace),
                "num_documents": len(documents),
                "perturbation_applied": len(words_to_replace) > 0,
                "similarity_score": float(similarity_score),
                "original_ranking": original_ranking.tolist(),
                "perturbed_ranking": perturbed_ranking.tolist(),
                "perturbed_documents": perturbed_docs # Sample of perturbed documents
            }
            
            perturbed_results.append((mask, perturbed_docs, perturbation_info))
            
            if mask_idx < 5:  # Debug output
                print(f"\nMask {mask_idx}: words_to_replace = {words_to_replace}")
                print(f"  Similarity score: {similarity_score}")
                if len(documents) > 0:
                    print(f"  Original: {documents[0][:100]}...")
                    print(f"  Perturbed: {perturbed_docs[0][:100]}...")
        
        if save_perturbed:
            if output_filename is None:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                output_filename = f"perturbed_data_{timestamp}.npz"
            
            output_path = os.path.join(self.output_dir, output_filename)
            self._save_perturbed_data(perturbed_results, output_path, {
                "masks_filepath": masks_filepath,
                "query": query,
                "num_documents": len(documents),
                "original_ranking": original_ranking.tolist()
                # "original_metadata": {k: v.item() if hasattr(v, 'item') else v for k, v in data.items() if k != 'masks'}
            })
        
        return perturbed_results
    
    

    def calculate_shap_from_perturbed(
        self,
        perturbed_data_filepath: str,
        query_features: List[str],
        query_id: str = ""
    ) -> AttributionExplanation:
        """
        Step 3: Calculate SHAP values using SHAP's kernel weights
        and weighted least squares on precomputed masks and scores.
        """
        print(f"Calculating SHAP values from: {perturbed_data_filepath}")
        
        # Load precomputed data
        data = np.load(perturbed_data_filepath, allow_pickle=True)
        perturbed_data_list = data['perturbed_data'].item()
        
        masks = []
        scores = []
        for item in perturbed_data_list:
            masks.append(np.array(item['mask']))
            scores.append(item['perturbation_info']['similarity_score'])
        
        masks = np.array(masks)
        scores = np.array(scores)
        
        print(f"Loaded {len(masks)} precomputed mask-score pairs")
        
        # Compute SHAP values using SHAP's kernel and weighted regression
        shap_values = self._compute_shap_from_masks_and_scores(
            masks, scores, len(query_features)
        )
        
        # Build explanation
        exp_word_dict = {
            query_features[i]: shap_values[i] 
            for i in range(min(len(shap_values), len(query_features)))
        }
        exp_word_list = sorted(exp_word_dict.items(), key=lambda x: x[1], reverse=True)
        
        explanation = AttributionExplanation(
            explanation=exp_word_list,
            num_features=len(query_features),
            query_id=query_id
        )
        
        return explanation


    def _convert_masks_to_binary(self, masks, num_features):
        """Convert string masks to binary matrix for SHAP computation."""
        mask_matrix = np.zeros((len(masks), num_features))
        
        for i, mask in enumerate(masks):
            for j in range(min(len(mask), num_features)):
                # 1 if feature is kept, 0 if masked
                mask_matrix[i, j] = 1.0 if mask[j] == '<keep>' else 0.0
        
        return mask_matrix

    # UTILITY METHODS
    
    def _save_perturbed_data(self, perturbed_results, filepath, metadata):
        """Save perturbed data to file."""
        save_data = {
            "perturbed_data": [
                {
                    "mask": mask.tolist(),
                    "perturbed_documents": perturbed_docs,
                    "perturbation_info": perturbation_info
                }
                for mask, perturbed_docs, perturbation_info in perturbed_results
            ],
            "metadata": metadata,
            "num_perturbations": len(perturbed_results)
        }
        
        np.savez_compressed(filepath, **save_data)
        print(f"Perturbed data saved to: {filepath}")
    
    def _convert_numpy_types(self, obj):
        """Convert numpy types to native Python types for JSON serialization."""
        if isinstance(obj, dict):
            return {key: self._convert_numpy_types(value) for key, value in obj.items()}
        elif isinstance(obj, list):
            return [self._convert_numpy_types(item) for item in obj]
        elif isinstance(obj, tuple):
            return tuple(self._convert_numpy_types(item) for item in obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        else:
            return obj

    # CONVENIENCE METHOD FOR FULL DECOUPLED PIPELINE
    
    def run_decoupled_pipeline(
        self,
        query_features: List[str],
        documents: List[str],
        query: str,
        query_id: str = "",
        save_intermediate: bool = True
    ) -> AttributionExplanation:
        """
        Run the complete decoupled pipeline in sequence.
        
        Args:
            query_features: List of feature tokens for the query
            documents: List of documents to analyze
            query: Query string
            query_id: Query identifier
            save_intermediate: Whether to save intermediate results
            
        Returns:
            Final AttributionExplanation
        """
        print("=== Step 1: Generating Masks ===")
        masks, metadata = self.generate_masks_only(
            query_features, query_id, save_masks=save_intermediate
        )
        
        if save_intermediate:
            # Use the saved file
            timestamp = metadata['timestamp'].replace(':', '').replace('-', '').replace('T', '_')[:15]
            masks_file = os.path.join(self.output_dir, f"masks_{query_id}_{timestamp}.npz")
        else:
            # Save temporarily
            masks_file = os.path.join(self.output_dir, "temp_masks.npz")
            np.savez_compressed(masks_file, masks=masks, **metadata)
        
        print("\n=== Step 2: Applying Masks to Documents and Computing Scores ===")
        perturbed_results = self.apply_masks_to_documents(
            masks_file, documents, query, save_perturbed=save_intermediate
        )
        
        if save_intermediate:
            perturbed_file = os.path.join(self.output_dir, f"perturbed_data_{timestamp}.npz")
        else:
            perturbed_file = os.path.join(self.output_dir, "temp_perturbed.npz")
        
        print("\n=== Step 3: Calculating SHAP Values Using Internal SHAP Mechanism ===")
        explanation = self.calculate_shap_from_perturbed(
            perturbed_file, query_features, query_id
        )
        
        # Clean up temporary files if not saving intermediate results
        if not save_intermediate:
            for temp_file in [masks_file, perturbed_file]:
                if os.path.exists(temp_file) and "temp_" in temp_file:
                    os.remove(temp_file)
        
        return explanation

    def _compute_shap_from_masks_and_scores(
        self, 
        masks: np.ndarray, 
        scores: np.ndarray, 
        num_features: int
    ) -> np.ndarray:
        """
        Compute SHAP-inspired attributions from precomputed masks and scores.
        
        Addresses: boundary coalitions, efficiency, deduplication, numerical stability.
        """
        # 1. Ensure boundary coalitions exist (Issue #1)
        masks, scores = self._ensure_boundary_coalitions(masks, scores, num_features)
        
        # 2. Deduplicate masks (Issue #6)
        masks, scores, repeat_counts = self._deduplicate_masks_and_scores(masks, scores)
        
        # 3. Convert to binary
        mask_matrix = self._convert_masks_to_binary(masks, num_features)
        coalition_sizes = mask_matrix.sum(axis=1).astype(int)
        
        # 4. Compute kernel weights (Issue #3 - avoid private API)
        kernel_weights = self._compute_shapley_kernel_weights(coalition_sizes, num_features)
        kernel_weights = kernel_weights * repeat_counts  # Account for duplicates
        
        # 5. Center scores for stability (Issue #7)
        y_mean = np.average(scores, weights=kernel_weights)
        scores_centered = scores - y_mean
        
        # 6. Efficient weighted least squares (Issue #5)
        shap_values = self._weighted_least_squares_efficient(
            mask_matrix, scores_centered, kernel_weights
        )
        
        shap_values = shap_values[1:]

        # 7. Verify efficiency axiom (Issue #2)
        # self._check_efficiency_axiom(mask_matrix, scores, shap_values, num_features)
        
        return shap_values
    


    def _ensure_boundary_coalitions(self, masks, scores, num_features):
        """
        Ensure empty and full coalitions are present.
        Add them with appropriate scores if missing.
        """
        # Convert to binary for checking
        mask_matrix = self._convert_masks_to_binary(masks, num_features)
        
        # Check for empty coalition (all 0s)
        empty_coalition = np.zeros(num_features)
        has_empty = any(np.array_equal(row, empty_coalition) for row in mask_matrix)
        
        # Check for full coalition (all 1s)
        full_coalition = np.ones(num_features)
        has_full = any(np.array_equal(row, full_coalition) for row in mask_matrix)
        
        new_masks = list(masks)
        new_scores = list(scores)
        
        if not has_empty:
            print("WARNING: Adding missing empty coalition")
            # Need to compute score for empty coalition
            # This should be 1.0 (perfect similarity when all features masked)
            empty_mask = np.array(['<unk>'] * num_features)
            new_masks.insert(0, empty_mask)
            new_scores.insert(0, 1.0)  # or compute properly
        
        if not has_full:
            print("WARNING: Adding missing full coalition")
            # Score for full coalition (no masking)
            full_mask = np.array(['<keep>'] * num_features)
            new_masks.insert(0, full_mask)
            new_scores.insert(0, 1.0)  # This should be perfect similarity
        
        return np.array(new_masks), np.array(new_scores)
    

    def _compute_shapley_kernel_weights(self, coalition_sizes, num_features):
        """
        Compute SHAP kernel weights without using private API.
        Formula: w(s) = (M-1) / [C(M,s) * s * (M-s)]
        """
        import scipy.special
        
        M = num_features
        weights = np.zeros(len(coalition_sizes))
        
        for i, s in enumerate(coalition_sizes):
            if s == 0 or s == M:
                weights[i] = 1e6  # Large weight for boundary coalitions
            else:
                weights[i] = (M - 1) / (
                    scipy.special.comb(M, s) * s * (M - s)
                )
        
        return weights
    

    def _weighted_least_squares_efficient(self, X, y, weights):
        """
        Efficient weighted least squares via row scaling.
        
        Memory: O(NM) instead of O(N²)
        Stable: Uses QR-based lstsq instead of normal equations
        """
        X_with_intercept = np.hstack([np.ones((len(X), 1)), X])
        # Scale rows by sqrt(weights)
        sqrt_weights = np.sqrt(weights)
        X_weighted = X_with_intercept * sqrt_weights[:, np.newaxis]
        y_weighted = y * sqrt_weights
        
        # Solve using stable method
        try:
            # lstsq uses QR decomposition internally
            coefficients, residuals, rank, singular_values = np.linalg.lstsq(
                X_weighted, 
                y_weighted, 
                rcond=None
            )
            
            # Check conditioning
            if rank < X.shape[1]:
                print(f"WARNING: Rank deficient matrix (rank={rank}/{X.shape[1]})")
                
        except np.linalg.LinAlgError as e:
            print(f"LinAlgError: {e}, using pseudoinverse")
            coefficients = np.linalg.pinv(X_weighted) @ y_weighted
        
        return coefficients[1:]


    def _deduplicate_masks_and_scores(self, masks, scores):
        """
        Collapse duplicate masks by averaging scores and increasing weights.
        """
        from collections import defaultdict
        
        # Group by mask
        mask_to_indices = defaultdict(list)
        for i, mask in enumerate(masks):
            mask_key = tuple(mask.flatten())
            mask_to_indices[mask_key].append(i)
        
        # Deduplicate
        unique_masks = []
        unique_scores = []
        repeat_counts = []
        
        for mask_key, indices in mask_to_indices.items():
            unique_masks.append(masks[indices[0]])
            # Average scores for duplicates
            unique_scores.append(np.mean([scores[i] for i in indices]))
            repeat_counts.append(len(indices))
        
        if len(unique_masks) < len(masks):
            print(f"Collapsed {len(masks)} masks to {len(unique_masks)} unique masks")
        
        return np.array(unique_masks), np.array(unique_scores), np.array(repeat_counts)                   








