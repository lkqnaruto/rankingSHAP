import json
from rank_bm25 import BM25Okapi
from typing import List, Dict, Any, Tuple
import re

class BM25SearchEngine:
    def __init__(self, k1: float = 1.2, b: float = 0.75):
        """
        Initialize BM25 search engine with Elasticsearch-like functionality.
        
        Args:
            k1: Controls term frequency saturation (default 1.2, same as Elasticsearch)
            b: Controls field length normalization (default 0.75, same as Elasticsearch)
        """
        self.k1 = k1
        self.b = b
        self.bm25 = None
        self.documents = []
        self.tokenized_docs = []
        
    def preprocess_text(self, text: str) -> List[str]:
        """
        Preprocess text similar to Elasticsearch's standard analyzer.
        - Convert to lowercase
        - Remove punctuation
        - Split on whitespace
        """
        # Convert to lowercase and remove punctuation
        text = re.sub(r'[^\w\s]', ' ', text.lower())
        # Split and filter empty strings
        tokens = [token for token in text.split() if token]
        return tokens
    
    def index_documents(self, documents: List[Dict[str, Any]], text_field: str = 'text'):
        """
        Index documents for BM25 search.
        
        Args:
            documents: List of document dictionaries
            text_field: Field name containing the text to index
        """
        self.documents = documents
        self.tokenized_docs = []
        
        for doc in documents:
            # if text_field in doc:
            tokens = self.preprocess_text(doc)
            self.tokenized_docs.append(tokens)
            # else:
            #     self.tokenized_docs.append([])
        
        # Initialize BM25 with custom parameters
        self.bm25 = BM25Okapi(self.tokenized_docs, k1=self.k1, b=self.b)
        
        print(f"Indexed {len(documents)} documents")
    
    def search(self, query: str, top_k: int = 10) -> List[Dict[str, Any]]:
        """
        Search documents using BM25 scoring.
        
        Args:
            query: Search query string
            top_k: Number of top results to return
            
        Returns:
            List of search results with scores and documents
        """
        if self.bm25 is None:
            raise ValueError("No documents indexed. Call index_documents() first.")
        
        # Tokenize query using same preprocessing
        query_tokens = self.preprocess_text(query)
        
        # Get BM25 scores for all documents
        scores = self.bm25.get_scores(query_tokens)
        
        # Create results with scores and original documents
        results = []
        for i, score in enumerate(scores):
            if score >= 0:  # Only include documents with positive scores
                result = {
                    '_score': float(score),
                    '_source': self.documents[i],
                    '_index': i
                }
                results.append(result)
        
        # Sort by score (descending) and return top_k
        results.sort(key=lambda x: x['_score'], reverse=True)
        return results[:top_k]
    
    def get_top_k(self, query: str, k: int = 10) -> List[Tuple[int, float]]:
        """
        Get top-k document indices and scores for a query.
        
        Returns:
            List of (document_index, score) tuples
        """
        if self.bm25 is None:
            raise ValueError("No documents indexed. Call index_documents() first.")
        
        query_tokens = self.preprocess_text(query)
        scores = self.bm25.get_scores(query_tokens)
        
        # Get top-k indices
        top_indices = scores.argsort()[-k:][::-1]
        # print(scores)
        return [(int(idx), float(scores[idx])) for idx in top_indices if scores[idx] > 0]
    
    # def explain_score(self, query: str, doc_index: int) -> Dict[str, Any]:
    #     """
    #     Provide score explanation similar to Elasticsearch's _explain API.
    #     """
    #     if self.bm25 is None:
    #         raise ValueError("No documents indexed.")
        
    #     if doc_index >= len(self.documents):
    #         raise ValueError("Document index out of range.")
        
    #     query_tokens = self.preprocess_text(query)
    #     doc_tokens = self.tokenized_docs[doc_index]
        
    #     # Calculate individual term contributions
    #     term_explanations = []
    #     for term in query_tokens:
    #         if term in doc_tokens:
    #             # This is a simplified explanation - actual BM25 calculation is more complex
    #             tf = doc_tokens.count(term)
    #             term_explanations.append({
    #                 'term': term,
    #                 'term_frequency': tf,
    #                 'found_in_document': True
    #             })
    #         else:
    #             term_explanations.append({
    #                 'term': term,
    #                 'term_frequency': 0,
    #                 'found_in_document': False
    #             })
        
    #     total_score = self.bm25.get_scores([query_tokens])[0] if len(self.bm25.doc_freqs) > doc_index else 0
        
    #     return {
    #         'score': float(total_score),
    #         'query_terms': term_explanations,
    #         'document_length': len(doc_tokens),
    #         'average_document_length': self.bm25.avgdl
    #     }


# Example usage and demo
def demo_bm25_search(query, documents):

    target_documents = documents
    # Initialize search engine
    search_engine = BM25SearchEngine()
    
    # Index documents
    search_engine.index_documents(target_documents, text_field='text')

    # print(f"\n{'='*50}")
    # print(f"Query: '{query}'")
    # print('='*50)

    results = search_engine.search(query, top_k=len(target_documents))
    # print(results)
    # for i, result in enumerate(results, 1):
    #     print(f"\n{i}. Score: {result['_score']:.4f}")
        # print(f"   Title: {result['_source']['title']}")
        # print(f"   Text: {result['_source']['text'][:100]}...")
    return results

